#ifndef RESULT_H_INCLUDED
#define RESULT_H_INCLUDED
#include <iostream>
#include "Unit.h"

using namespace std;

class Result
{
public:
    Result();       // default constructor
    Result(const Unit &unit, float mark);

    // Get and Set Methods
    float GetMark() const;
    void GetUnit(Unit &unit) const;

    friend ostream &operator<<(ostream &ostr, const Result &result);
    friend istream &operator>>(istream &input, Result &result);

private:
    Unit m_unit;
    float m_mark;
};

#endif // RESULT_H_INCLUDED
