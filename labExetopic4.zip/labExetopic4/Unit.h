#ifndef UNIT_H
#define UNIT_H

#include <iostream>
#include <cstring>  // C string library needed here for the C string routines.

using namespace std;

const unsigned UNIT_NAME_SIZE = 10;
const unsigned UNIT_ID_SIZE = 8;

class Unit
{
public:
  Unit();
  Unit(const char *nam, const char *id, unsigned credits);

  unsigned GetCredits() const;
  void SetCredits(unsigned cred);

  friend ostream &operator<<(ostream &os, const Unit &unit);
  /** \brief
   *
   * \param input istream&
   * \param unit Unit&
   * \return friend istream&
   *
   */
  friend istream &operator>>(istream &input, Unit &unit);

private:
  char m_name[UNIT_NAME_SIZE + 1]; // course name, c style string, not a c++ string object
  char m_id[UNIT_ID_SIZE + 1];     // ict283, ict375, ict285, BA
  unsigned m_credits;              // number of credits
};

#endif
