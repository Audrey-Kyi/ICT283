#include <iostream>
#include <fstream>

#include "Result.h"
#include "Registration.h"

using namespace std;

int main() {
    // Read from file
    ifstream infile("rinput.txt");
    if (!infile) return -1;

    Registration R;
    infile >> R;

    ofstream ofile("routput.txt");
    ofile << R
          << "Number of Units = " << R.GetCount() << '\n'
          << "Total Credits   = " << R.GetCredits() << '\n';

          Unit aUnit( "MYH_3020", "B", 2);
          aUnit.SetCredits( 5 );
          cout << aUnit << endl;

    return 0;
}
