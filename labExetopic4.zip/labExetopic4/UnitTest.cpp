#include <iostream>
#include "Unit.h"

using namespace std;

int main()
{
    Unit firstUnit;     // Default constructor

    Unit secondUnit("Data Structure", "ICT283", 3);

    cout << "--First Unit --" << endl;
    cout << firstUnit << endl;

    cout << "--Second Unit --" << endl;
    cout << secondUnit << endl;

    return 0;
}

