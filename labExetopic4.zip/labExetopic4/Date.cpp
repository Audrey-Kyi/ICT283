// Date.cpp

#include "Date.h"

Date::Date() : m_day(0), m_month(0), m_year(0) {}

Date::Date(int day, int month, int year) : m_day(day), m_month(month), m_year(year) {}

int Date::getDay() const {
    return m_day;
}

void Date::setDay(int day) {
    m_day = day;
}

int Date::getMonth() const {
    return m_month;
}

void Date::setMonth(int month) {
    m_month = month;
}

int Date::getYear() const {
    return m_year;
}

void Date::setYear(int year) {
    m_year = year;
}

std::ostream& operator<<(std::ostream& os, const Date& date) {
    os << date.m_day << " " << date.m_month << " " << date.m_year;
    return os;
}

std::istream& operator>>(std::istream& is, Date& date) {
    is >> date.m_day >> date.m_month >> date.m_year;
    return is;
}
