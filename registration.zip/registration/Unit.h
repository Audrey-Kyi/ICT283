#ifndef UNIT_H
#define UNIT_H
#include <iostream>
#include <string>

using namespace std;
using std::string;

class Unit
{
public:
    Unit();
    Unit(const string& name, const string& id, unsigned credits);

    unsigned GetCredits() const;
    void GetName(string& name) const;
    void GetId(string& id) const;

    void SetCredits(unsigned cred);
    void SetName(const string& name);
    void SetId(const string& id);



private:
    string m_name;
    string m_id;
    unsigned m_credits;
};

istream & operator >> (istream &input, Unit &unit);

ostream & operator << (ostream &os, const Unit &unit);


#endif
