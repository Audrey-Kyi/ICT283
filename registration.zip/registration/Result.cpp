#include "Result.h"

Result::Result()
{
    m_mark = 0;
}
Result::Result(const Unit & unit, float mark)
{
	m_unit = unit;
	m_mark = mark;
}

float Result::GetMark() const		// return by value
{
	return m_mark;
}
void Result::GetUnit(Unit & unit) const	// return by reference
{
	unit = m_unit;
}

void Result::SetMark(float mark)
{
   m_mark = mark;
}

void Result::SetUnit(const Unit & unit)
{
   m_unit = unit;
}

//Functions
ostream & operator << ( ostream & ostr, const Result & result )
{
    Unit tempUnit;
    result.GetUnit(tempUnit);   // pass by refrence

	ostr << tempUnit << "  Marks   : " << result.GetMark() << '\n';
	return ostr;
}

istream & operator >> ( istream & input, Result & result )
{
    Unit tempUnit;
	input >> tempUnit;
	result.SetUnit(tempUnit);

    string data;
    getline(input, data);
   // result.m_mark = stoi(data);
    result.SetMark(stoi(data));
	return input;
}
