#include "Registration.h"

Registration::Registration()
{
    m_count = 0;
}

unsigned Registration::GetCredits() const
{
    unsigned sum = 0;
    Unit tempUnit;
    for(unsigned i = 0; i < m_count; i++)
    {
        m_results[i].GetUnit(tempUnit);
        sum += tempUnit.GetCredits();
    }
    return sum;
}

unsigned Registration::GetCount() const
{
    return m_count;
}

long Registration::GetStudentId() const
{
    return m_studentId;
}

unsigned Registration::GetSemester() const
{
    return m_semester;
}

const Result* Registration::GetResults() const
{
    return m_results;
}

void Registration::GetResults(unsigned index, Result & result)const
{
    result = m_results[index];
}

void Registration::SetCount(unsigned count)
{
    m_count = count;
}

void Registration::SetStudentID(long studentId)
{
    m_studentId = studentId;
}

void Registration::SetSemester(unsigned semester)
{
    m_semester = semester;
}

istream & operator >> (istream & input, Registration & registration )
{
    input >> registration.m_studentId >> registration.m_semester;

    string data;
    getline(input, data);
    registration.m_count = stoi(data);

    for(unsigned i = 0; i < registration.m_count; i++)
    {
        input >> registration.m_results[i];
    }
    return input;
}

ostream & operator << (ostream & os, const Registration & registration )
{
    os << "Student ID: " << registration.GetStudentId() << '\n'
       << "Semester:   " << registration.GetSemester() << '\n';

    Result tempResult;

    for (unsigned i = 0; i < registration.GetCount(); i++)
    {
        registration.GetResults(i, tempResult);

        os << tempResult << '\n'; // Use the results pointer to access elements
    }

    /* const Result* results = registration.GetResults();

    for (unsigned i = 0; i < registration.GetCount(); i++)
    {
        os << results[i] << '\n'; // Use the results pointer to access elements
    } */


    return os;
}
