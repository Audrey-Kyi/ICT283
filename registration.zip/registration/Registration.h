
#ifndef REGISTRATION_H
#define REGISTRATION_H

#include <iostream>
#include <string>
#include "Result.h" // Assuming you have a Result class defined elsewhere

using namespace std;

class Registration
{
public:

    Registration();
    unsigned GetCredits() const;
    unsigned GetCount() const;
    long GetStudentId() const;
    unsigned GetSemester() const;
    const Result* GetResults() const;   // return the array of the result
    void GetResults(unsigned index, Result & result)const;  // return the single result object based on index

    void SetCount(unsigned count);
    void SetStudentID(long studentId);
    void SetSemester(unsigned semester);

    friend istream & operator >> (istream & input, Registration & registration);
    friend ostream & operator << (ostream & os, const Registration & registration);

private:
    long m_studentId;         ///< The student ID.
    unsigned m_semester;      ///< The semester.
    unsigned m_count;         ///< The count of results.
    Result m_results[10];     ///< Array of results (assuming maximum size of 10).
};

#endif // REGISTRATION_H
